import { MdDoNotDisturbAlt, MdOutlineBarChart } from "react-icons/md";
import { FaCheckCircle } from "react-icons/fa";
import { BiImport } from "react-icons/bi";
import { LiaFileImportSolid } from "react-icons/lia";
import { FaBell, FaHouseChimney } from "react-icons/fa6";
import { TfiAnnouncement } from "react-icons/tfi";
import { useSelector } from "react-redux";

export default function CourseStatus() {
  const { currentUser } = useSelector((state: any) => state.accountReducer);
  return (
    <div className="gx-2" id="wd-course-status" style={{ width: "300px" }}>
      {currentUser.role === "FACULTY" ?
        <>
          <h2>Course Status</h2>
          <div className="d-flex">
            <div className="w-50 pe-1">
              <button className="btn btn-lg btn-secondary w-100 text-nowrap px-2">
                <MdDoNotDisturbAlt className="me-2 fs-5 " /> Unpublish </button>
            </div>
            <div className="w-50">
              <button className="btn btn-lg btn-success w-100">
                <FaCheckCircle className="me-2 fs-5" /> Publish </button>
            </div>
          </div><br />
          <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
            <BiImport className="me-2 fs-5" /> Import Existing Content </button>
          <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
            <LiaFileImportSolid className="me-2 fs-5" /> Import from Commons </button>
          <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
            <FaHouseChimney className="me-2 fs-5" /> Choose Home Page </button>
          <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
            <MdOutlineBarChart className="me-2 fs-5" /> View Course Screen </button>
          <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
            <TfiAnnouncement className="me-2 fs-5" /> New Announcement </button>
        </> : null}
      <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
        <MdOutlineBarChart className="me-2 fs-5" /> New Analytics </button>
      <button className="btn btn-lg btn-secondary w-100 mt-1 text-start">
        <FaBell className="me-2 fs-5" /> View Course Notifications </button>
    </div >
  );
}

